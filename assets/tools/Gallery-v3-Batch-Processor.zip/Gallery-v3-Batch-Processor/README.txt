THETA CHI ZETA KAPPA — GALLERY V3 BATCH PROCESSOR
==================================================

PURPOSE
-------
This processor prepares raw gallery photos for the future TCZK admin portal.
It does NOT modify the live gallery database and does NOT upload anything to R2.

Each source image produces TWO WebP files:
  display/  = max 1800 x 1800, WebP quality 84
  thumbs/   = max 600 x 600, WebP quality 76

Those settings match the current Gallery v2 processor so new images remain
compatible with the existing gallery images already stored in R2.

FIRST-TIME SETUP
----------------
Double-click install-processor.bat once.
This installs Pillow and pillow-heif for JPG/JPEG/PNG/WEBP/HEIC/HEIF support.

CREATE A GALLERY BATCH
----------------------
1. Put the RAW photos you want to add in a folder.
2. Double-click run-processor.bat.
3. Paste or type the path to that folder.
4. Enter a fallback decade if needed.
5. Wait for processing to finish.
6. Open the batch-output folder.
7. Upload the newly created gallery-batch-....zip to the admin portal.

ZIP CONTENTS
------------
gallery-batch-....zip
  manifest.json
  display/
    matching-name.webp
  thumbs/
    matching-name.webp

The display and thumbnail versions always use the same WebP filename so the
admin portal can pair them automatically.

WHAT THE PROCESSOR DOES
-----------------------
- Supports JPG, JPEG, PNG, WEBP, HEIC and HEIF source files.
- Applies EXIF orientation before creating WebPs.
- Creates the existing gallery's 1800px display WebP.
- Creates the existing gallery's 600px thumbnail WebP.
- Uses a SHA-1 content hash in the WebP filename, matching the current naming
  approach and making filename collisions extremely unlikely.
- Skips duplicate source content within the same batch.
- Reads an EXIF year when available.
- Packages the output into one ZIP.

WHAT MOVED TO THE ADMIN PORTAL
------------------------------
The processor no longer owns a permanent gallery database or generates the
website's full gallery-data.js file. The admin portal will be responsible for:
- checking the batch against the existing live gallery for duplicates;
- reviewing images;
- changing year/decade metadata;
- rotating/removing images;
- maintaining hidden/unpublished records;
- publishing display and thumbnail WebPs to the existing R2 folders;
- updating the live gallery data automatically.

EXISTING GALLERY
----------------
The current images already in R2 do not need to be reprocessed or reuploaded.
The new system will import their existing records and keep their current URLs.
Only newly approved batches will add new R2 objects.
