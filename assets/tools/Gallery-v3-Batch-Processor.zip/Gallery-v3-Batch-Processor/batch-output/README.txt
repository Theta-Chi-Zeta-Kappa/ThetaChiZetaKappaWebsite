Processed gallery batch ZIPs will appear in this folder.
