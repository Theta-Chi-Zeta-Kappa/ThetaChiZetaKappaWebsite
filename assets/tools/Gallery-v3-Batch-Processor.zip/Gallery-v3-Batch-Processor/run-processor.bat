@echo off
setlocal
cd /d "%~dp0"
py gallery-processor.py
if errorlevel 1 (
  echo.
  echo The processor finished with an error or one or more failed images.
)
echo.
pause
