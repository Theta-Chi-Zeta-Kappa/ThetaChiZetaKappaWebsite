@echo off
setlocal
cd /d "%~dp0"
py -m pip install --upgrade Pillow pillow-heif
if errorlevel 1 (
  echo.
  echo Installation failed. Make sure Python is installed and the "py" launcher works.
) else (
  echo.
  echo Gallery processor dependencies installed successfully.
)
echo.
pause
