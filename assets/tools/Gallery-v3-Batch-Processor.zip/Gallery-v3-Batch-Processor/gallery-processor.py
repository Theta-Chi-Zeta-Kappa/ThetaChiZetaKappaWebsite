#!/usr/bin/env python3
"""Theta Chi Zeta Kappa Gallery v3 batch processor.

Takes a folder of raw photos and creates one upload-ready ZIP containing:
  display/*.webp
  thumbs/*.webp
  manifest.json

The processor intentionally does NOT read or modify the live gallery database.
The future admin portal is responsible for duplicate checks against the live
catalog, review, rotations, metadata changes, and publishing to R2.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

try:
    from PIL import Image, ImageOps
except ImportError:
    print("Missing dependency: Pillow")
    print("Run install-processor.bat first.")
    sys.exit(2)

HEIC_READY = False
try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
    HEIC_READY = True
except Exception:
    pass

SUPPORTED = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif"}
HEIC_EXTS = {".heic", ".heif"}
ROOT = Path(__file__).resolve().parent
OUTPUT_ROOT = ROOT / "batch-output"

DISPLAY_MAX = 1800
DISPLAY_QUALITY = 84
THUMB_MAX = 600
THUMB_QUALITY = 76
MANIFEST_VERSION = 1


def clean_stem(stem: str) -> str:
    stem = re.sub(r"[^a-z0-9]+", "-", stem.strip().lower())
    return re.sub(r"-+", "-", stem).strip("-") or "photo"


def file_digest(path: Path) -> str:
    h = hashlib.sha1()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def extract_year(img: Image.Image) -> Optional[int]:
    try:
        exif = img.getexif()
        for tag in (36867, 36868, 306):
            value = exif.get(tag) if exif else None
            if value:
                m = re.match(r"(19|20)\d{2}", str(value))
                if m:
                    return int(m.group(0))
    except Exception:
        pass
    return None


def infer_decade(year: Optional[int], fallback: str) -> str:
    if year and 1900 <= year <= 2099:
        return f"{(year // 10) * 10}s"
    return fallback


def open_oriented(path: Path) -> Image.Image:
    opened = Image.open(path)
    try:
        oriented = ImageOps.exif_transpose(opened)
        return oriented.copy()
    finally:
        opened.close()


def save_webp(img: Image.Image, target: Path, max_size: int, quality: int) -> None:
    copy = img.copy()
    copy.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
    if copy.mode not in ("RGB", "RGBA"):
        copy = copy.convert("RGBA" if "A" in copy.getbands() else "RGB")
    target.parent.mkdir(parents=True, exist_ok=True)
    copy.save(target, "WEBP", quality=quality, method=6)


def unique_web_name(path: Path, digest: str, used_names: set[str]) -> str:
    base = f"{clean_stem(path.stem)}-{digest[:10]}"
    candidate = f"{base}.webp"
    if candidate not in used_names:
        used_names.add(candidate)
        return candidate
    # Practically unreachable unless two different paths normalize identically
    # while sharing the same digest, but keep ZIP names unambiguous.
    suffix = 2
    while f"{base}-{suffix}.webp" in used_names:
        suffix += 1
    candidate = f"{base}-{suffix}.webp"
    used_names.add(candidate)
    return candidate


def build_zip(batch_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.write(batch_dir / "manifest.json", "manifest.json")
        for folder in ("display", "thumbs"):
            for path in sorted((batch_dir / folder).glob("*.webp")):
                zf.write(path, f"{folder}/{path.name}")


def parse_args():
    p = argparse.ArgumentParser(description="Create one admin-uploadable gallery batch ZIP.")
    p.add_argument("input", nargs="?", help="Folder containing source photos")
    p.add_argument("--decade", default="2020s", help="Fallback decade when no EXIF year exists")
    p.add_argument("--output", help="Optional output ZIP path")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    if not args.input:
        print("Theta Chi Zeta Kappa — Gallery v3 Batch Processor")
        args.input = input("Folder containing photos: ").strip().strip('"')
        decade = input(f"Fallback decade [{args.decade}]: ").strip()
        if decade:
            args.decade = decade

    src_dir = Path(args.input).expanduser().resolve()
    if not src_dir.is_dir():
        print(f"ERROR: Folder does not exist: {src_dir}")
        return 2

    files = sorted(p for p in src_dir.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED)
    if not files:
        print("No supported images found.")
        return 1
    if any(p.suffix.lower() in HEIC_EXTS for p in files) and not HEIC_READY:
        print("HEIC/HEIF found but HEIC support is missing. Run install-processor.bat.")
        return 3

    batch_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    batch_dir = OUTPUT_ROOT / f"gallery-batch-{batch_id}"
    batch_dir.mkdir(parents=True, exist_ok=False)
    (batch_dir / "display").mkdir()
    (batch_dir / "thumbs").mkdir()

    seen_digests: set[str] = set()
    used_names: set[str] = set()
    records = []
    duplicates = 0
    failed = 0

    print(f"Found {len(files)} source image(s).")
    for index, path in enumerate(files, 1):
        try:
            digest = file_digest(path)
            if digest in seen_digests:
                duplicates += 1
                print(f"[{index}/{len(files)}] duplicate in this batch skipped: {path.name}")
                continue

            img = open_oriented(path)
            try:
                width, height = img.size
                year = extract_year(Image.open(path))
                web_file = unique_web_name(path, digest, used_names)
                save_webp(img, batch_dir / "thumbs" / web_file, THUMB_MAX, THUMB_QUALITY)
                save_webp(img, batch_dir / "display" / web_file, DISPLAY_MAX, DISPLAY_QUALITY)
            finally:
                img.close()

            records.append({
                "id": f"batch-{uuid.uuid4().hex[:12]}",
                "digest": digest,
                "originalName": path.name,
                "webFile": web_file,
                "width": width,
                "height": height,
                "year": year,
                "decade": infer_decade(year, args.decade),
                "alt": path.stem.replace("_", " ").replace("-", " ").strip(),
                "rotation": 0,
            })
            seen_digests.add(digest)
            print(f"[{index}/{len(files)}] processed: {path.name}")
        except Exception as exc:
            failed += 1
            print(f"[{index}/{len(files)}] FAILED {path.name}: {exc}")

    manifest = {
        "manifestVersion": MANIFEST_VERSION,
        "processor": "Theta Chi Zeta Kappa Gallery v3",
        "batchId": batch_id,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "imageFormat": "webp",
        "display": {"folder": "display", "maxPixels": DISPLAY_MAX, "quality": DISPLAY_QUALITY},
        "thumbnail": {"folder": "thumbs", "maxPixels": THUMB_MAX, "quality": THUMB_QUALITY},
        "images": records,
    }
    (batch_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    if args.output:
        zip_path = Path(args.output).expanduser().resolve()
        zip_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        zip_path = OUTPUT_ROOT / f"gallery-batch-{batch_id}.zip"
    build_zip(batch_dir, zip_path)

    print("\nFinished")
    print(f"Processed:  {len(records)}")
    print(f"Duplicates: {duplicates}")
    print(f"Failed:     {failed}")
    print(f"Batch ID:   {batch_id}")
    print(f"ZIP:        {zip_path}")
    print("\nUpload this single ZIP to the Gallery section of the admin portal.")
    print("The admin portal will handle live-gallery duplicate checks, review, rotation, metadata, and publishing.")
    return 4 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
